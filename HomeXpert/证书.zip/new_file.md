HBRMF2673U

App ID Prefix
HBRMF2673U(TeamID)
BundleID
com.wojohub.homexpert (explicit)

密码是Wojo@1588